﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class menuScript : MonoBehaviour {

	public GameObject menuPanel;
	public GameObject infoPanel;

	// Use this for initialization
	void Start () {
		menuPanel.SetActive(true);
		infoPanel.SetActive(false);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void startButtonClicked()
	{
		Application.LoadLevel("Loading2");
	}

	public void quitButtonClicked()
	{
		Application.Quit();
	}
	public void infoButtonClicked() 
	{
		infoPanel.SetActive(true);
		menuPanel.SetActive(false);
	}
	public void backButtonClicked()
	{
		menuPanel.SetActive(true);
		infoPanel.SetActive(false);
	}
}
